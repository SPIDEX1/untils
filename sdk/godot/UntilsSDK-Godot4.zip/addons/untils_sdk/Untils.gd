extends Node
## Untils Godot SDK 1.0.0 - for Godot 4.x (Web export)
## Docs: https://untils.pages.dev/developers/docs/
##
## Install: enable the plugin "UNTILS SDK" (Project > Project Settings > Plugins), or add this file
## yourself as an Autoload named "Untils" (Project > Project Settings > Autoload).
##
## Use:    var info = await Untils.init()
##         var coins = Untils.get_int("coins", 0)

signal initialized(info)
signal paused
signal resumed
signal ad_finished(ad_type, rewarded)
signal score_submitted(board, ok)
signal _replied(req_id, result)

const SDK_NAME = "Godot SDK"
const SDK_VERSION = "1.0.0"
const SAVE_PATH = "user://untils_prefs.json"

## true after init() finished
var is_ready = false
## "untils" (on the site), "offline" (web build on your own PC) or "editor" (not a web build)
var env = "editor"
var is_mobile = false
var language = "en"
var player = {"guest": true, "name": "Guest"}
## ads are not live yet
var ads_available = false
## When true (default) the game and sound are paused while the tab is hidden.
var auto_pause = true
## When true (default) loading_start / loading_finished are sent for you.
var auto_loading = true
## In the editor and offline only: what a rewarded ad returns, so you can test your reward code.
var editor_rewarded_result = true
var debug = false

var _web = false
var _gd = null
var _cb = null
var _data = {}
var _seq = 0
var _init_started = false
var _we_paused = false
var _we_muted = false
var _save_timer = null

const _JS_SDK = """/*! HTML SDK (untils.js) v1.2.0 | Docs: /developers/docs/ */
(function (w) {
  "use strict";
  var NAME = "HTML SDK", VERSION = "1.2.0", TIMEOUT = 3000, OFF = "untils_sdk_offline", MAXSAVE = 900000;
  var env = "none", ready = false, data = {}, player = { guest: true, name: "Guest" }, debug = false, ctx = { url: "", params: "" };
  var mobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && Math.min(screen.width, screen.height) < 820);
  var pend = {}, seq = 0, pauseCb = [], resumeCb = [], paused = false, saveT = 0, loading = false, playing = false;

  function log() { if (debug) { try { console.log.apply(console, ["[Untils]"].concat([].slice.call(arguments))); } catch (e) {} } }
  function warn(m) { try { console.warn("[Untils] " + m); } catch (e) {} }
  function noop() {}
  function inFrame() { try { return w.parent && w.parent !== w; } catch (e) { return false; } }
  function send(type, extra, ms) {
    return new Promise(function (res, rej) {
      var id = ++seq, m = { untils: 1, id: id, type: type }, k;
      for (k in extra) m[k] = extra[k];
      var t = setTimeout(function () { delete pend[id]; rej(new Error("timeout")); }, ms || TIMEOUT);
      pend[id] = function (r) { clearTimeout(t); res(r); };
      try { w.parent.postMessage(m, "*"); } catch (e) { clearTimeout(t); delete pend[id]; rej(e); }
    });
  }
  function fire(list) { list.forEach(function (f) { try { f(); } catch (e) { console.error(e); } }); }
  function evt(type, extra) { log(type, extra || ""); if (ready && env === "untils") send(type, extra || {}).catch(noop); }
  function flush() {
    clearTimeout(saveT);
    if (env === "untils") send("save", { data: data }).catch(noop);
    else { try { w.localStorage.setItem(OFF, JSON.stringify(data)); } catch (e) {} }
  }
  function persist() { clearTimeout(saveT); saveT = setTimeout(flush, 150); }
  function info() { return { name: NAME, version: VERSION, env: env, isMobile: mobile, player: player, language: lang() }; }
  function lang() { return String((navigator.language || "en")).slice(0, 2).toLowerCase(); }
  function need(n) { if (!ready) { warn("Call Untils.init() first, before Untils." + n + "()."); return false; } return true; }
  function doPause() {
    if (paused) return;
    paused = true;
    if (playing) { playing = false; evt("gameplay", { state: "stop", auto: true }); }
    fire(pauseCb);
  }
  function doResume() { if (paused) { paused = false; fire(resumeCb); } }
  function params() { try { return new URLSearchParams(env === "untils" ? ctx.params : w.location.search); } catch (e) { return new URLSearchParams(""); } }

  w.addEventListener("message", function (e) {
    var m = e.data;
    if (!m || m.untils !== 1 || e.source !== w.parent) return;
    if (m.ev === "pause") { doPause(); return; }
    if (m.ev === "resume") { doResume(); return; }
    if (m.id && pend[m.id]) { var f = pend[m.id]; delete pend[m.id]; f(m); }
  });
  document.addEventListener("visibilitychange", function () { if (document.hidden) doPause(); else doResume(); });
  w.addEventListener("pagehide", function () { if (ready) flush(); });
  var errN = 0;
  w.addEventListener("error", function (e) {
    if (ready && env === "untils" && errN++ < 20) evt("error", { message: String((e && e.message) || "error").slice(0, 200), source: String((e && e.filename) || "").slice(-80), line: (e && e.lineno) || 0 });
  });
  w.addEventListener("unhandledrejection", function (e) {
    var r = e && e.reason;
    if (ready && env === "untils" && errN++ < 20) evt("error", { message: ("Unhandled promise: " + String((r && r.message) || r)).slice(0, 200) });
  });

  w.Untils = {
    sdkName: NAME,
    version: VERSION,
    adsAvailable: false,
    get env() { return env; },
    get isMobile() { return mobile; },
    get isReady() { return ready; },

    /* Start: always call first. Resolves with { name, version, env, isMobile, player, language }. Never rejects. */
    init: function (opts) {
      if (opts && opts.debug) debug = true;
      if (ready) return Promise.resolve(info());
      var p = inFrame() ? send("init", { sdk: NAME, sdkVersion: VERSION, via: (opts && opts.via) || "" }).then(function (r) {
        if (!r || !r.ok || !r.data) throw new Error("bad reply");
        env = "untils"; data = r.data.data || {}; player = r.data.player || player;
        ctx = { url: r.data.url || "", params: r.data.params || "" };
        if (r.data.mobile != null) mobile = !!r.data.mobile;
      }) : Promise.reject(new Error("standalone"));
      return p.catch(function () {
        env = "offline";
        try { data = JSON.parse(w.localStorage.getItem(OFF) || "{}") || {}; } catch (e) { data = {}; }
      }).then(function () { ready = true; log("ready", info()); return info(); });
    },
    setDebug: function (on) { debug = !!on; },

    /* Used by engine plugins (for example Untils SDK Unity) to tell UNTILS which plugin is running. */
    announce: function (name, version) { if (ready && env === "untils") send("announce", { name: String(name), version: String(version) }).catch(noop); },

    /* Loading and gameplay state */
    loadingStart: function () { if (!need("loadingStart") || loading) return; loading = true; evt("loading", { state: "start" }); },
    loadingFinished: function () { if (!need("loadingFinished") || !loading) return; loading = false; evt("loading", { state: "finished" }); },
    gameplayStart: function () { if (!need("gameplayStart") || playing) return; playing = true; evt("gameplay", { state: "start" }); },
    gameplayStop: function () { if (!need("gameplayStop") || !playing) return; playing = false; evt("gameplay", { state: "stop" }); },

    /* Save data: any JSON value. About 900 KB total per game. */
    save: function (key, value) {
      if (!need("save")) return Promise.resolve(false);
      if (typeof key !== "string" || !key) { warn("save(key, value): key must be a non-empty string."); return Promise.resolve(false); }
      var had = Object.prototype.hasOwnProperty.call(data, key), prev = data[key];
      try { data[key] = JSON.parse(JSON.stringify(value === undefined ? null : value)); } catch (e) { warn("save(): value must be JSON-safe."); return Promise.resolve(false); }
      if (JSON.stringify(data).length > MAXSAVE) {
        if (had) data[key] = prev; else delete data[key];
        warn("save(): too much data (limit about 900 KB per game). Nothing was saved for \\"" + key + "\\".");
        return Promise.resolve(false);
      }
      persist(); return Promise.resolve(true);
    },
    load: function (key, fallback) {
      if (!need("load")) return Promise.resolve(fallback);
      return Promise.resolve(Object.prototype.hasOwnProperty.call(data, key) ? data[key] : fallback);
    },
    remove: function (key) { if (!need("remove")) return Promise.resolve(false); delete data[key]; persist(); return Promise.resolve(true); },
    clearSave: function () { if (!need("clearSave")) return Promise.resolve(false); data = {}; persist(); return Promise.resolve(true); },
    keys: function () { return need("keys") ? Object.keys(data) : []; },

    /* Pause / resume (tab hidden, app switched). gameplayStop is sent for you when the tab is hidden. */
    onPause: function (fn) { if (typeof fn === "function") pauseCb.push(fn); },
    onResume: function (fn) { if (typeof fn === "function") resumeCb.push(fn); },

    /* Player and device */
    getPlayer: function () { return Promise.resolve({ guest: player.guest !== false, name: player.name || "Guest" }); },
    getLanguage: function () { return lang(); },

    /* Share links: shareableURL({level: 5}) gives a link; the game reads it with getURLParam("level") */
    shareableURL: function (obj) {
      var base = (env === "untils" && ctx.url) || (w.location.origin + w.location.pathname), q = [], k;
      for (k in (obj || {})) if (Object.prototype.hasOwnProperty.call(obj, k)) q.push("u_" + encodeURIComponent(k) + "=" + encodeURIComponent(String(obj[k])));
      return base + (q.length ? "?" + q.join("&") : "");
    },
    getURLParam: function (name) { var v = params().get("u_" + name); return v === null ? undefined : v; },

    /* Screen */
    requestFullscreen: function () { if (need("requestFullscreen")) evt("fullscreen", { state: true }); },
    exitFullscreen: function () { if (need("exitFullscreen")) evt("fullscreen", { state: false }); },

    /* Your own events for stats: track("level_complete", { level: 3 }). Collected by UNTILS later. */
    track: function (name, extra) {
      if (!need("track")) return;
      if (typeof name !== "string" || !name || name.length > 40) { warn("track(name, data): name must be a string up to 40 characters."); return; }
      evt("track", { name: name, data: extra === undefined ? null : extra });
    },

    /* Ads: not live yet. Interstitial resolves true (continue), rewarded resolves false (no reward). */
    showAd: function (type) {
      if (type !== "interstitial" && type !== "rewarded") { warn('showAd("interstitial" | "rewarded")'); return Promise.resolve(false); }
      var free = type === "interstitial";
      if (!ready || env !== "untils") return Promise.resolve(free);
      return send("ad", { kind: type }, 60000).then(function (r) {
        var d = (r && r.data) || {};
        return type === "rewarded" ? d.rewarded === true : true;
      }).catch(function () { return free; });
    },
    commercialBreak: function () { return this.showAd("interstitial"); },
    rewardedBreak: function () { return this.showAd("rewarded"); },

    /* Leaderboards: coming with player login. Safe to call now. */
    submitScore: function (board, score) {
      if (!ready || env !== "untils") return Promise.resolve(false);
      return send("score", { board: String(board), score: Number(score) }).then(function (r) { return !!(r && r.data && r.data.saved); }).catch(function () { return false; });
    }
  };
})(window);
"""

const _JS_BRIDGE = """/* Untils Godot SDK bridge: connects GDScript to untils.js (HTML SDK). */
(function (w) {
  "use strict";
  var U = w.Untils, cb = null, hooked = false;
  function send(kind, id, payload) {
    if (!cb) return;
    try { cb(kind, id, JSON.stringify(payload === undefined ? null : payload)); }
    catch (e) { try { console.warn("[Untils] could not reply to Godot", e); } catch (x) {} }
  }
  function parse(arg) { try { return arg ? JSON.parse(arg) : {}; } catch (e) { return {}; } }
  w.__untilsGD = {
    setCb: function (f) { cb = f; },
    /* async calls: the answer comes back through the callback as ("r", id, json) */
    req: function (id, name, arg) {
      var a = parse(arg);
      var reply = function (r) { send("r", id, r); };
      try {
        if (name === "init") {
          U.init({ via: "godot" }).then(function (info) {
            if (!hooked) {
              hooked = true;
              U.onPause(function () { send("ev", "pause", ""); });
              U.onResume(function () { send("ev", "resume", ""); });
            }
            if (U.announce) U.announce("Godot SDK", "1.0.0");
            var keys = U.keys(), data = {};
            Promise.all(keys.map(function (k) { return U.load(k, null).then(function (v) { data[k] = v; }); }))
              .then(function () { reply({ info: info, data: data }); });
          }, function () { reply({ error: "init failed" }); });
        } else if (name === "showAd") {
          U.showAd(a.type).then(function (ok) { reply({ ok: !!ok }); });
        } else if (name === "submitScore") {
          U.submitScore(a.board, a.score).then(function (ok) { reply({ ok: !!ok }); });
        } else {
          reply({ error: "unknown call " + name });
        }
      } catch (e) { reply({ error: String(e) }); }
    },
    /* fire and forget */
    act: function (name, arg) {
      var a = parse(arg);
      try {
        switch (name) {
          case "loadingStart": U.loadingStart(); break;
          case "loadingFinished": U.loadingFinished(); break;
          case "gameplayStart": U.gameplayStart(); break;
          case "gameplayStop": U.gameplayStop(); break;
          case "save": U.save(a.key, a.value); break;
          case "remove": U.remove(a.key); break;
          case "clearSave": U.clearSave(); break;
          case "requestFullscreen": U.requestFullscreen(); break;
          case "exitFullscreen": U.exitFullscreen(); break;
          case "setDebug": U.setDebug(!!a.on); break;
          case "track": U.track(a.name, a.data); break;
        }
      } catch (e) { try { console.warn("[Untils] " + name + " failed", e); } catch (x) {} }
    },
    /* answers right away, as a JSON text */
    sync: function (name, arg) {
      var a = parse(arg), v = null;
      try {
        if (name === "shareableURL") v = U.shareableURL(a);
        else if (name === "getURLParam") v = U.getURLParam(a.name);
      } catch (e) { v = null; }
      return JSON.stringify(v === undefined ? null : v);
    }
  };
})(window);
"""


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	_save_timer = Timer.new()
	_save_timer.one_shot = true
	_save_timer.wait_time = 0.15
	add_child(_save_timer)
	_save_timer.timeout.connect(_flush_local)


# ---------- Start ----------

## Starts the SDK and loads saved data. Call it first. Never fails.
## Use "var info = await Untils.init()", or connect to the "initialized" signal.
func init(debug_on = false):
	if debug_on:
		debug = true
	if is_ready:
		return _info()
	if _init_started:
		await initialized
		return _info()
	_init_started = true
	process_mode = Node.PROCESS_MODE_ALWAYS
	_web = OS.has_feature("web")
	if not _web:
		env = "editor"
		is_mobile = OS.has_feature("mobile")
		language = OS.get_locale_language()
		_load_local()
		_finish()
		return _info()
	_cb = JavaScriptBridge.create_callback(_on_js)
	var has_sdk = JavaScriptBridge.eval("typeof window.Untils !== 'undefined'", true)
	if not has_sdk:
		JavaScriptBridge.eval(_JS_SDK, true)
	JavaScriptBridge.eval(_JS_BRIDGE, true)
	_gd = JavaScriptBridge.get_interface("__untilsGD")
	_gd.setCb(_cb)
	if debug:
		_act("setDebug", {"on": true})
	var res = await _request("init")
	if typeof(res) == TYPE_DICTIONARY and res.has("info"):
		var inf_d = res["info"]
		env = str(inf_d.get("env", "offline"))
		is_mobile = bool(inf_d.get("isMobile", false))
		language = str(inf_d.get("language", "en"))
		if typeof(inf_d.get("player")) == TYPE_DICTIONARY:
			player = inf_d["player"]
		if typeof(res.get("data")) == TYPE_DICTIONARY:
			_data = res["data"]
	else:
		env = "offline"
		_warn("Could not start the web SDK. Running offline.")
	_finish()
	return _info()


func set_debug(on):
	debug = bool(on)
	_act("setDebug", {"on": debug})


# ---------- Loading and gameplay state ----------

func loading_start():
	if _need("loading_start"):
		_act("loadingStart")

func loading_finished():
	if _need("loading_finished"):
		_act("loadingFinished")

func gameplay_start():
	if _need("gameplay_start"):
		_act("gameplayStart")

func gameplay_stop():
	if _need("gameplay_stop"):
		_act("gameplayStop")


# ---------- Player, language, share links ----------

func get_player():
	return player

func get_language():
	return language

## Link to your game with your own values in it. Show it in a "Share" button.
func shareable_url(values = {}):
	if _web and _gd != null:
		var r = JSON.parse_string(str(_gd.sync("shareableURL", JSON.stringify(values))))
		return str(r) if r != null else ""
	return ""

## Reads a value from the link the player opened. Returns default_value if missing.
func get_url_param(param_name, default_value = ""):
	if _web and _gd != null:
		var r = JSON.parse_string(str(_gd.sync("getURLParam", JSON.stringify({"name": param_name}))))
		if r != null:
			return str(r)
	return default_value


# ---------- Screen ----------

func request_fullscreen():
	if _need("request_fullscreen"):
		_act("requestFullscreen")

func exit_fullscreen():
	if _need("exit_fullscreen"):
		_act("exitFullscreen")


# ---------- Your own events (stats come later) ----------

func track(event_name, data = null):
	if _need("track"):
		_act("track", {"name": event_name, "data": data})


# ---------- Ads (not live yet) ----------

## ad_type: "interstitial" or "rewarded". Use "var ok = await Untils.show_ad(...)".
## Interstitial gives true (continue). Rewarded gives false until ads are live.
func show_ad(ad_type):
	if ad_type != "interstitial" and ad_type != "rewarded":
		_warn("show_ad(\"interstitial\" or \"rewarded\")")
		await get_tree().process_frame
		ad_finished.emit(ad_type, false)
		return false
	if not (_web and env == "untils"):
		var free_ok = true if ad_type == "interstitial" else editor_rewarded_result
		await get_tree().process_frame
		ad_finished.emit(ad_type, free_ok)
		return free_ok
	var res = await _request("showAd", {"type": ad_type})
	var ok = typeof(res) == TYPE_DICTIONARY and bool(res.get("ok", false))
	ad_finished.emit(ad_type, ok)
	return ok

func commercial_break():
	await show_ad("interstitial")

func rewarded_break():
	var ok = await show_ad("rewarded")
	return ok


# ---------- Leaderboards (coming soon, safe to call now) ----------

func submit_score(board, score):
	if not (_web and env == "untils"):
		await get_tree().process_frame
		score_submitted.emit(board, false)
		return false
	var res = await _request("submitScore", {"board": str(board), "score": float(score)})
	var ok = typeof(res) == TYPE_DICTIONARY and bool(res.get("ok", false))
	score_submitted.emit(board, ok)
	return ok


# ---------- Save data (works like PlayerPrefs). About 900 KB per game. ----------
# Saves itself shortly after each change. Use these instead of user:// files,
# because browser storage is blocked in the UNTILS sandbox.

func set_int(key, value):
	_write(key, int(value))

func get_int(key, default_value = 0):
	var v = _read(key)
	if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
		return int(v)
	return default_value

func set_float(key, value):
	_write(key, float(value))

func get_float(key, default_value = 0.0):
	var v = _read(key)
	if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
		return float(v)
	return default_value

func set_string(key, value):
	_write(key, str(value))

func get_string(key, default_value = ""):
	var v = _read(key)
	if typeof(v) == TYPE_STRING:
		return v
	return default_value

func set_bool(key, value):
	_write(key, bool(value))

func get_bool(key, default_value = false):
	var v = _read(key)
	if typeof(v) == TYPE_BOOL:
		return v
	return default_value

## Any JSON value: Dictionary, Array, number, text, bool.
func set_json(key, value):
	var copy = JSON.parse_string(JSON.stringify(value))
	if copy == null and value != null:
		_warn("set_json(): value must be JSON-safe (Dictionary, Array, number, text, bool).")
		return false
	return _write(key, copy)

func get_json(key, default_value = null):
	var v = _read(key)
	if v == null:
		return default_value
	return v

func has_key(key):
	return _data.has(key)

func keys():
	return _data.keys()

func delete_key(key):
	if not _need("delete_key"):
		return
	_data.erase(key)
	if _web and _gd != null:
		_act("remove", {"key": key})
	else:
		_schedule_save()

func delete_all():
	if not _need("delete_all"):
		return
	_data = {}
	if _web and _gd != null:
		_act("clearSave")
	else:
		_schedule_save()

## Saves now (it already saves by itself shortly after each change).
func save_now():
	if not (_web and _gd != null):
		_flush_local()


# ---------- Internal ----------

func _info():
	return {"name": SDK_NAME, "version": SDK_VERSION, "env": env, "isMobile": is_mobile, "player": player, "language": language}

func _finish():
	is_ready = true
	_log("ready", _info())
	initialized.emit(_info())
	if auto_loading and _web:
		loading_start()
		await get_tree().process_frame
		await get_tree().process_frame
		loading_finished()

func _log(a, b = ""):
	if debug:
		print("[Untils] ", a, " ", b)

func _warn(msg):
	push_warning("[Untils] " + msg)

func _need(fn_name):
	if not is_ready:
		_warn("Call Untils.init() first, before " + fn_name + "().")
		return false
	return true

func _act(call_name, arg = {}):
	if _web and _gd != null:
		_gd.act(call_name, JSON.stringify(arg))

func _request(call_name, arg = {}):
	_seq += 1
	var req_id = _seq
	_gd.req(req_id, call_name, JSON.stringify(arg))
	get_tree().create_timer(6.0).timeout.connect(func(): _replied.emit(req_id, null))
	while true:
		var r = await _replied
		if int(r[0]) == req_id:
			return r[1]

func _on_js(args):
	var kind = str(args[0])
	if kind == "r":
		var res = null
		if str(args[2]) != "":
			res = JSON.parse_string(str(args[2]))
		_replied.emit(int(args[1]), res)
	elif kind == "ev":
		var ev = str(args[1])
		if ev == "pause":
			_do_pause()
		elif ev == "resume":
			_do_resume()

func _do_pause():
	if auto_pause:
		if not get_tree().paused:
			get_tree().paused = true
			_we_paused = true
		var bus = AudioServer.get_bus_index("Master")
		if bus >= 0 and not AudioServer.is_bus_mute(bus):
			AudioServer.set_bus_mute(bus, true)
			_we_muted = true
	paused.emit()

func _do_resume():
	if auto_pause:
		if _we_paused:
			get_tree().paused = false
			_we_paused = false
		if _we_muted:
			var bus = AudioServer.get_bus_index("Master")
			if bus >= 0:
				AudioServer.set_bus_mute(bus, false)
			_we_muted = false
	resumed.emit()

func _read(key):
	if not _need("get"):
		return null
	if _data.has(key):
		return _data[key]
	return null

func _write(key, value):
	if not _need("set"):
		return false
	if typeof(key) != TYPE_STRING or key == "":
		_warn("The key must be a non-empty text.")
		return false
	_data[key] = value
	if _web and _gd != null:
		_act("save", {"key": key, "value": value})
	else:
		_schedule_save()
	return true

func _schedule_save():
	if _save_timer != null:
		_save_timer.start()

func _load_local():
	_data = {}
	if FileAccess.file_exists(SAVE_PATH):
		var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f != null:
			var parsed = JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_DICTIONARY:
				_data = parsed

func _flush_local():
	var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(_data))
