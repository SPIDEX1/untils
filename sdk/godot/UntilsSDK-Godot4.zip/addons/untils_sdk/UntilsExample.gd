extends Control
# Example (Godot 4.x): "Coin Tapper".
# Attach this script to a Control node (Layout: Full Rect) in a new scene and run it.
# It needs the Autoload "Untils" (enable the plugin "UNTILS SDK").

var coins = 0
var is_ready_ok = false
var playing = false
var status_label = Label.new()
var coins_label = Label.new()


func _ready():
	var box = VBoxContainer.new()
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(box)
	for l in [status_label, coins_label]:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.add_theme_font_size_override("font_size", 28)
		box.add_child(l)
	box.add_child(_make_button("TAP!", _on_tap))
	box.add_child(_make_button("Watch ad: +50 coins", _on_watch_ad))
	box.add_child(_make_button("Reset", _on_reset))
	_set_status("starting...")

	Untils.paused.connect(func(): _set_status("Paused"))
	Untils.resumed.connect(func(): _set_status("Welcome back!"))

	var info = await Untils.init()
	coins = Untils.get_int("coins", 0)  # saved progress
	is_ready_ok = true
	_show_coins()
	_set_status("SDK %s | env: %s | %s | %s" % [Untils.SDK_VERSION, info["env"], "mobile" if info["isMobile"] else "desktop", info["language"]])


func _make_button(text, method):
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 90)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(method)
	return b


func _on_tap():
	if not is_ready_ok:
		return
	if not playing:
		playing = true
		Untils.gameplay_start()
	coins += 1
	Untils.set_int("coins", coins)  # saved automatically
	Untils.track("tap", {"coins": coins})
	_show_coins()


func _on_watch_ad():
	if not is_ready_ok:
		return
	var rewarded = await Untils.rewarded_break()
	if rewarded:
		coins += 50
		Untils.set_int("coins", coins)
		_show_coins()
		_set_status("+50 coins!")
	else:
		_set_status("Ads are not live yet, so no reward.")


func _on_reset():
	if not is_ready_ok:
		return
	coins = 0
	Untils.delete_all()
	_show_coins()
	_set_status("Progress reset.")


func _exit_tree():
	if playing:
		Untils.gameplay_stop()


func _show_coins():
	coins_label.text = "Coins: " + str(coins)


func _set_status(s):
	status_label.text = s
