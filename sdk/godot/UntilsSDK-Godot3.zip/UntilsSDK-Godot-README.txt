Godot SDK 1.0.0 (beta) - for Godot 3.x (HTML5 export)
======================================================================
(Made for Godot 3.x (3.5 recommended). Godot 4.x has its own package on the docs page.)

1. Unzip this file INTO your Godot project folder (the folder that contains "project.godot").
   Say yes to merging folders. You get addons/untils_sdk/ with:
     Untils.gd           the SDK (it already contains untils.js, nothing else to copy)
     UntilsExample.gd    a small example ("Coin Tapper")
     plugin.cfg/gd       the editor plugin
2. Project > Project Settings > Plugins: tick "Enable" for "UNTILS SDK".
   This adds the Autoload "Untils" for you. (Or add addons/untils_sdk/Untils.gd yourself as an
   Autoload named "Untils": Project Settings > Autoload.)
3. In your first script call Untils.init() once at the start, and use Untils.set_int / get_int ...
   instead of user:// files:

       var info = yield(Untils.init(), "completed")
       var level = Untils.get_int("level", 1)

   See addons/untils_sdk/UntilsExample.gd for a full example.
4. Project > Export > Add... > HTML5. Recommended settings:
     Options > Export Type: Regular  (not "Threads": threads need special server headers, UNTILS does not set them)
   Project Settings > Display > Window > Stretch: Mode = 2d, Aspect = expand
   (so the game fits phones and PC).
5. Click "Export Project", name the file index.html, and export into an empty folder.
6. Zip the CONTENTS of that folder (index.html must be at the top of the zip) and upload it in your
   UNTILS developer dashboard. After upload, open the Inspector view to check the SDK.

Loading events are sent for you. The game and sound are paused for you when the tab is hidden
(Untils.auto_pause).

Docs: https://untils.pages.dev/developers/docs/
