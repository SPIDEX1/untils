tool
extends EditorPlugin

const AUTOLOAD_NAME = "Untils"
const AUTOLOAD_PATH = "res://addons/untils_sdk/Untils.gd"


func _enter_tree():
	add_autoload_singleton(AUTOLOAD_NAME, AUTOLOAD_PATH)


func _exit_tree():
	remove_autoload_singleton(AUTOLOAD_NAME)
