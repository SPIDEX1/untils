extends Control
# Example (Godot 3.x): "Coin Tapper".
# Attach this script to a Control node (Layout: Full Rect) in a new scene and run it.
# It needs the Autoload "Untils" (enable the plugin "UNTILS SDK").

var coins = 0
var is_ready_ok = false
var playing = false
var status_label = Label.new()
var coins_label = Label.new()


func _ready():
	var box = VBoxContainer.new()
	box.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	box.alignment = BoxContainer.ALIGN_CENTER
	add_child(box)
	for l in [status_label, coins_label]:
		l.align = Label.ALIGN_CENTER
		l.autowrap = true
		box.add_child(l)
	box.add_child(_make_button("TAP!", "_on_tap"))
	box.add_child(_make_button("Watch ad: +50 coins", "_on_watch_ad"))
	box.add_child(_make_button("Reset", "_on_reset"))
	_set_status("starting...")

	Untils.connect("paused", self, "_on_untils_paused")
	Untils.connect("resumed", self, "_on_untils_resumed")

	var info = yield(Untils.init(), "completed")
	coins = Untils.get_int("coins", 0)  # saved progress
	is_ready_ok = true
	_show_coins()
	_set_status("SDK %s | env: %s | %s | %s" % [Untils.SDK_VERSION, info["env"], "mobile" if info["isMobile"] else "desktop", info["language"]])


func _make_button(text, method):
	var b = Button.new()
	b.text = text
	b.rect_min_size = Vector2(0, 90)
	b.connect("pressed", self, method)
	return b


func _on_untils_paused():
	_set_status("Paused")


func _on_untils_resumed():
	_set_status("Welcome back!")


func _on_tap():
	if not is_ready_ok:
		return
	if not playing:
		playing = true
		Untils.gameplay_start()
	coins += 1
	Untils.set_int("coins", coins)  # saved automatically
	Untils.track("tap", {"coins": coins})
	_show_coins()


func _on_watch_ad():
	if not is_ready_ok:
		return
	var rewarded = yield(Untils.rewarded_break(), "completed")
	if rewarded:
		coins += 50
		Untils.set_int("coins", coins)
		_show_coins()
		_set_status("+50 coins!")
	else:
		_set_status("Ads are not live yet, so no reward.")


func _on_reset():
	if not is_ready_ok:
		return
	coins = 0
	Untils.delete_all()
	_show_coins()
	_set_status("Progress reset.")


func _exit_tree():
	if playing:
		Untils.gameplay_stop()


func _show_coins():
	coins_label.text = "Coins: " + str(coins)


func _set_status(s):
	status_label.text = s
