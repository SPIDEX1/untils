// Untils Cocos SDK v1.0.0 - for Cocos Creator 3.x (3.0 and newer), Web (HTML5) builds
// Docs: https://untils.pages.dev/developers/docs/
//
// Use:   import { Untils, UntilsPrefs } from './UntilsSDK/Untils';
//        Untils.init().then(() => { ... });
//
// This file talks to untils.js (the HTML SDK). untils.js is copied into your build
// automatically from build-templates/web-mobile/untils.js.

import { game, director, Director, sys } from 'cc';

export interface UntilsPlayer { guest: boolean; name: string; }
export interface UntilsInfo { name: string; version: string; env: string; isMobile: boolean; player: UntilsPlayer; language: string; }
export type UntilsAdType = 'interstitial' | 'rewarded';
type Cb = () => void;

const SDK_NAME = 'Cocos SDK';
const SDK_VERSION = '1.0.0';
const LS_KEY = 'untils_cocos_prefs';
const W: any = (typeof window !== 'undefined') ? window : undefined;

let debug = false;
let ready = false;
let env = 'editor';                         // "untils" (on the site), "offline" (your own PC / preview) or "editor"
let mobile = false;
let language = 'en';
let player: UntilsPlayer = { guest: true, name: 'Guest' };
let html: any = null;                       // the HTML SDK (window.Untils)
let initP: Promise<UntilsInfo> | null = null;
let loadingDone = false;
const pauseCbs: Cb[] = [];
const resumeCbs: Cb[] = [];

function log(...a: any[]): void { if (debug) { try { console.log('[Untils]', ...a); } catch (e) { /* ignore */ } } }
function warn(m: string): void { try { console.warn('[Untils] ' + m); } catch (e) { /* ignore */ } }
function fire(list: Cb[]): void { list.forEach((f) => { try { f(); } catch (e) { console.error(e); } }); }
function needInit(n: string): boolean { if (!ready) { warn('Call Untils.init() first, before ' + n + '().'); return false; } return true; }

function loadScript(src: string): Promise<boolean> {
    return new Promise<boolean>((resolve) => {
        try {
            const d = W.document;
            const s = d.createElement('script');
            let done = false;
            const fin = (ok: boolean): void => { if (!done) { done = true; resolve(ok); } };
            s.src = src; s.async = true;
            s.onload = (): void => fin(true);
            s.onerror = (): void => fin(false);
            d.head.appendChild(s);
            setTimeout(() => fin(false), 6000);
        } catch (e) { resolve(false); }
    });
}

function lsGet(): string | null {
    try { if (W && W.localStorage) { return W.localStorage.getItem(LS_KEY); } } catch (e) { /* ignore */ }
    try { return sys.localStorage.getItem(LS_KEY); } catch (e) { /* ignore */ }
    return null;
}
function lsSet(v: string): void {
    try { if (W && W.localStorage) { W.localStorage.setItem(LS_KEY, v); return; } } catch (e) { /* ignore */ }
    try { sys.localStorage.setItem(LS_KEY, v); } catch (e) { /* ignore */ }
}

function doPause(): void {
    if (Untils.autoPause) { try { game.pause(); } catch (e) { /* ignore */ } }
    fire(pauseCbs);
}
function doResume(): void {
    if (Untils.autoPause) { try { game.resume(); } catch (e) { /* ignore */ } }
    fire(resumeCbs);
}
function info(): UntilsInfo { return { name: SDK_NAME, version: SDK_VERSION, env: env, isMobile: mobile, player: player, language: language }; }

/** Main SDK. Call Untils.init() once at the start of your game. */
export class Untils {
    static readonly sdkName = SDK_NAME;
    static readonly version = SDK_VERSION;

    /** When true (default) the game loop and sound are paused while the tab is hidden. */
    static autoPause = true;
    /** When true (default) loadingStart / loadingFinished are sent for you. Set to false to call them yourself. */
    static autoLoading = true;
    /** In preview / offline only: what a rewarded ad returns, so you can test your reward code. */
    static editorRewardedResult = true;

    static get isReady(): boolean { return ready; }
    static get env(): string { return env; }
    static get isMobile(): boolean { return mobile; }
    static get language(): string { return language; }
    static get player(): UntilsPlayer { return player; }
    static get adsAvailable(): boolean { return false; }   // ads are not live yet

    /** Starts the SDK and loads saved data. Call it first. Never rejects. Waits up to about 3 seconds for UNTILS. */
    static init(opts?: { debug?: boolean }): Promise<UntilsInfo> {
        if (opts && opts.debug) { debug = true; }
        if (initP) { return initP; }
        mobile = !!sys.isMobile;
        initP = new Promise<UntilsInfo>((resolve) => {
            const finish = (): void => {
                UntilsPrefs._load().then(() => {
                    ready = true;
                    log('ready', info());
                    if (Untils.autoLoading) { Untils._autoLoading(); }
                    resolve(info());
                });
            };
            if (!W || !W.document) { env = 'editor'; finish(); return; }
            const go = (): void => {
                html = W.Untils || null;
                if (!html) {
                    warn('untils.js was not found. Copy untils.js to build-templates/web-mobile/ (it is in the SDK zip) and build again. Running offline.');
                    env = 'offline'; finish(); return;
                }
                html.init({ debug: debug, via: 'cocos' }).then((r: any) => {
                    env = r.env || 'offline';
                    mobile = !!r.isMobile; language = r.language || 'en';
                    player = r.player || player;
                    html.onPause(doPause); html.onResume(doResume);
                    if (html.announce) { html.announce(SDK_NAME, SDK_VERSION); }
                    finish();
                }, () => { env = 'offline'; finish(); });
            };
            if (W.Untils) { go(); } else { loadScript('untils.js').then(go); }
        });
        return initP;
    }

    static setDebug(on: boolean): void { debug = !!on; if (html && html.setDebug) { html.setDebug(!!on); } }

    // ---------- Loading and gameplay state ----------
    static loadingStart(): void { if (needInit('loadingStart') && html) { html.loadingStart(); } }
    static loadingFinished(): void { if (needInit('loadingFinished') && html) { html.loadingFinished(); } }
    static gameplayStart(): void { if (needInit('gameplayStart') && html) { html.gameplayStart(); } }
    static gameplayStop(): void { if (needInit('gameplayStop') && html) { html.gameplayStop(); } }

    // ---------- Pause / resume (tab hidden or shown) ----------
    static onPause(cb: Cb): void { if (typeof cb === 'function') { pauseCbs.push(cb); } }
    static onResume(cb: Cb): void { if (typeof cb === 'function') { resumeCbs.push(cb); } }
    static offPause(cb: Cb): void { const i = pauseCbs.indexOf(cb); if (i > -1) { pauseCbs.splice(i, 1); } }
    static offResume(cb: Cb): void { const i = resumeCbs.indexOf(cb); if (i > -1) { resumeCbs.splice(i, 1); } }

    // ---------- Player, language, share links ----------
    static getPlayer(): Promise<UntilsPlayer> { return html ? html.getPlayer() : Promise.resolve(player); }
    static getLanguage(): string { return language; }
    static shareableURL(values: { [key: string]: any }): string {
        if (html) { return html.shareableURL(values || {}); }
        return (W && W.location) ? (W.location.origin + W.location.pathname) : '';
    }
    static getURLParam(name: string): string | undefined { return html ? html.getURLParam(name) : undefined; }

    // ---------- Screen ----------
    static requestFullscreen(): void { if (needInit('requestFullscreen') && html) { html.requestFullscreen(); } }
    static exitFullscreen(): void { if (needInit('exitFullscreen') && html) { html.exitFullscreen(); } }

    // ---------- Your own events (stats come later) ----------
    static track(name: string, data?: any): void { if (needInit('track') && html) { html.track(name, data); } }

    // ---------- Ads (not live yet) ----------
    /** Interstitial resolves true (continue). Rewarded resolves false until ads are live. */
    static showAd(type: UntilsAdType): Promise<boolean> {
        if (type !== 'interstitial' && type !== 'rewarded') { warn('showAd("interstitial" | "rewarded")'); return Promise.resolve(false); }
        if (!html || env !== 'untils') { return Promise.resolve(type === 'rewarded' ? Untils.editorRewardedResult : true); }
        return html.showAd(type);
    }
    static commercialBreak(): Promise<void> { return Untils.showAd('interstitial').then(() => undefined); }
    static rewardedBreak(): Promise<boolean> { return Untils.showAd('rewarded'); }

    // ---------- Leaderboards (coming soon, safe to call now) ----------
    static submitScore(board: string, score: number): Promise<boolean> { return html ? html.submitScore(board, score) : Promise.resolve(false); }

    // ---------- Save data (same as UntilsPrefs, async style like the HTML SDK) ----------
    static save(key: string, value: any): Promise<boolean> { return Promise.resolve(UntilsPrefs.setJSON(key, value)); }
    static load<T>(key: string, fallback: T): Promise<T> { return Promise.resolve(UntilsPrefs.getJSON<T>(key, fallback)); }
    static remove(key: string): Promise<boolean> { UntilsPrefs.deleteKey(key); return Promise.resolve(true); }
    static clearSave(): Promise<boolean> { UntilsPrefs.deleteAll(); return Promise.resolve(true); }
    static keys(): string[] { return UntilsPrefs.keys(); }

    /** @internal loading events done for you: start now, finished on the first drawn frame */
    static _autoLoading(): void {
        if (!html) { return; }
        html.loadingStart();
        const fin = (): void => { if (!loadingDone) { loadingDone = true; html.loadingFinished(); } };
        try { director.once(Director.EVENT_AFTER_DRAW, fin); } catch (e) { /* ignore */ }
        setTimeout(fin, 2500);
    }
}

/** Save-safe replacement for sys.localStorage. Saves itself shortly after each change (about 900 KB per game). */
export class UntilsPrefs {
    private static data: { [key: string]: any } = {};
    private static timer: any = 0;

    /** @internal loads everything that was saved before */
    static _load(): Promise<void> {
        UntilsPrefs.data = {};
        if (html) {
            let keys: string[] = [];
            try { keys = html.keys(); } catch (e) { keys = []; }
            return Promise.all(keys.map((k) => html.load(k, null).then((v: any) => { UntilsPrefs.data[k] = v; }))).then(() => undefined);
        }
        try { const raw = lsGet(); UntilsPrefs.data = raw ? (JSON.parse(raw) || {}) : {}; } catch (e) { UntilsPrefs.data = {}; }
        return Promise.resolve();
    }

    private static put(key: string, value: any): boolean {
        if (!needInit('UntilsPrefs.set')) { return false; }
        if (typeof key !== 'string' || !key) { warn('Prefs key must be a non-empty string.'); return false; }
        UntilsPrefs.data[key] = value;
        if (html) { html.save(key, value); } else { UntilsPrefs.schedule(); }
        return true;
    }
    private static schedule(): void {
        if (UntilsPrefs.timer) { clearTimeout(UntilsPrefs.timer); }
        UntilsPrefs.timer = setTimeout(UntilsPrefs.save, 150);
    }
    private static get(key: string): any {
        if (!needInit('UntilsPrefs.get')) { return undefined; }
        return Object.prototype.hasOwnProperty.call(UntilsPrefs.data, key) ? UntilsPrefs.data[key] : undefined;
    }

    static setInt(key: string, value: number): void { UntilsPrefs.put(key, Math.trunc(Number(value) || 0)); }
    static getInt(key: string, def = 0): number { const v = UntilsPrefs.get(key); return typeof v === 'number' ? Math.trunc(v) : def; }
    static setFloat(key: string, value: number): void { UntilsPrefs.put(key, Number(value) || 0); }
    static getFloat(key: string, def = 0): number { const v = UntilsPrefs.get(key); return typeof v === 'number' ? v : def; }
    static setString(key: string, value: string): void { UntilsPrefs.put(key, String(value)); }
    static getString(key: string, def = ''): string { const v = UntilsPrefs.get(key); return typeof v === 'string' ? v : def; }
    static setBool(key: string, value: boolean): void { UntilsPrefs.put(key, !!value); }
    static getBool(key: string, def = false): boolean { const v = UntilsPrefs.get(key); return typeof v === 'boolean' ? v : def; }
    /** Any JSON value: object, array, number, text. */
    static setJSON(key: string, value: any): boolean {
        try { return UntilsPrefs.put(key, JSON.parse(JSON.stringify(value === undefined ? null : value))); } catch (e) { warn('setJSON(): value must be JSON-safe.'); return false; }
    }
    static getJSON<T>(key: string, def: T): T { const v = UntilsPrefs.get(key); return v === undefined || v === null ? def : (v as T); }

    static hasKey(key: string): boolean { return Object.prototype.hasOwnProperty.call(UntilsPrefs.data, key); }
    static keys(): string[] { return Object.keys(UntilsPrefs.data); }
    static deleteKey(key: string): void {
        if (!needInit('UntilsPrefs.deleteKey')) { return; }
        delete UntilsPrefs.data[key];
        if (html) { html.remove(key); } else { UntilsPrefs.schedule(); }
    }
    static deleteAll(): void {
        if (!needInit('UntilsPrefs.deleteAll')) { return; }
        UntilsPrefs.data = {};
        if (html) { html.clearSave(); } else { UntilsPrefs.schedule(); }
    }
    /** Saves now (it already saves by itself shortly after each change). */
    static save = (): void => {
        if (UntilsPrefs.timer) { clearTimeout(UntilsPrefs.timer); UntilsPrefs.timer = 0; }
        if (!html) { try { lsSet(JSON.stringify(UntilsPrefs.data)); } catch (e) { /* ignore */ } }
    };
}
