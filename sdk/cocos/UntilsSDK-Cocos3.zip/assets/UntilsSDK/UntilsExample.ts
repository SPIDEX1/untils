// Example (Cocos Creator 3.x): "Coin Tapper".
// 1. Make a scene with 2 Labels (status, coins) and 3 Buttons (TAP, Watch ad, Reset).
// 2. Add this script to any node. Drag the Labels into "Status Label" and "Coins Label".
// 3. On each Button add a Click Event that calls onTap, onWatchAd or onReset on this node.
import { _decorator, Component, Label } from 'cc';
import { Untils, UntilsPrefs } from './Untils';
const { ccclass, property } = _decorator;

@ccclass('UntilsExample')
export class UntilsExample extends Component {
    @property(Label) statusLabel: Label | null = null;
    @property(Label) coinsLabel: Label | null = null;

    private coins = 0;
    private ready = false;
    private playing = false;

    start(): void {
        Untils.onPause(() => this.setStatus('Paused'));
        Untils.onResume(() => this.setStatus('Welcome back!'));

        Untils.init({ debug: true }).then((info) => {
            this.coins = UntilsPrefs.getInt('coins', 0);            // saved progress
            this.ready = true;
            this.showCoins();
            this.setStatus('SDK ' + Untils.version + ' | env: ' + info.env + ' | ' + (info.isMobile ? 'mobile' : 'desktop') + ' | ' + info.language);
        });
    }

    onTap(): void {
        if (!this.ready) { return; }
        if (!this.playing) { this.playing = true; Untils.gameplayStart(); }
        this.coins++;
        UntilsPrefs.setInt('coins', this.coins);                    // saved automatically
        Untils.track('tap', { coins: this.coins });
        this.showCoins();
    }

    onWatchAd(): void {
        if (!this.ready) { return; }
        Untils.rewardedBreak().then((rewarded) => {
            if (rewarded) {
                this.coins += 50;
                UntilsPrefs.setInt('coins', this.coins);
                this.showCoins();
                this.setStatus('+50 coins!');
            } else {
                this.setStatus('Ads are not live yet, so no reward.');
            }
        });
    }

    onReset(): void {
        if (!this.ready) { return; }
        this.coins = 0;
        UntilsPrefs.deleteAll();
        this.showCoins();
        this.setStatus('Progress reset.');
    }

    onDestroy(): void { if (this.playing) { Untils.gameplayStop(); } }

    private showCoins(): void { if (this.coinsLabel) { this.coinsLabel.string = 'Coins: ' + this.coins; } }
    private setStatus(s: string): void { if (this.statusLabel) { this.statusLabel.string = s; } }
}
