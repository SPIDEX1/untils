Cocos SDK 1.0.0 (beta) - for Cocos Creator 3.x (Web build)
======================================================================
(Made for Cocos Creator 3.x, written in TypeScript. Cocos Creator 2.4 has its own package on the docs page.)

1. Unzip this file INTO your Cocos project folder (the folder that contains "assets" and "settings").
   Say yes to merging folders. You get:
     assets/UntilsSDK/Untils.ts           the SDK (Untils and UntilsPrefs)
     assets/UntilsSDK/UntilsExample.ts    a small example scene script
     build-templates/web-mobile/untils.js  the HTML SDK, copied into your build for you
2. In your first script, call Untils.init() once at the start, and use UntilsPrefs instead of sys.localStorage:

       import { Untils, UntilsPrefs } from './UntilsSDK/Untils';
       Untils.init().then(() => { const level = UntilsPrefs.getInt('level', 1); /* start game */ });

   See assets/UntilsSDK/UntilsExample.ts for a full example.
3. Project > Build... > Platform "Web Mobile" (works on phones and PC). Pick the Orientation that matches
   the "Mobile screen" option you choose in the UNTILS dashboard. Click Build.
4. Open build/web-mobile and check that "untils.js" is next to "index.html".
5. Zip the CONTENTS of build/web-mobile (index.html must be at the top of the zip) and upload it in your
   UNTILS developer dashboard. After upload, open the Inspector view to check the SDK.

Loading events are sent for you. Pause and sound are handled for you when the tab is hidden (Untils.autoPause).

Docs: https://untils.pages.dev/developers/docs/
