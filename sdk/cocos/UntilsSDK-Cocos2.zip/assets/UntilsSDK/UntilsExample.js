// Example (Cocos Creator 2.4.x): "Coin Tapper".
// 1. Make a scene with 2 Labels (status, coins) and 3 Buttons (TAP, Watch ad, Reset).
// 2. Add this script to any node. Drag the Labels into "Status Label" and "Coins Label".
// 3. On each Button add a Click Event that calls onTap, onWatchAd or onReset on this node.
const { Untils, UntilsPrefs } = require("Untils");

cc.Class({
    extends: cc.Component,

    properties: {
        statusLabel: cc.Label,
        coinsLabel: cc.Label
    },

    start: function () {
        var self = this;
        this.coins = 0;
        this.ready = false;
        this.playing = false;

        Untils.onPause(function () { self.setStatus("Paused"); });
        Untils.onResume(function () { self.setStatus("Welcome back!"); });

        Untils.init({ debug: true }).then(function (info) {
            self.coins = UntilsPrefs.getInt("coins", 0);           // saved progress
            self.ready = true;
            self.showCoins();
            self.setStatus("SDK " + Untils.version + " | env: " + info.env + " | " + (info.isMobile ? "mobile" : "desktop") + " | " + info.language);
        });
    },

    onTap: function () {
        if (!this.ready) { return; }
        if (!this.playing) { this.playing = true; Untils.gameplayStart(); }
        this.coins++;
        UntilsPrefs.setInt("coins", this.coins);                   // saved automatically
        Untils.track("tap", { coins: this.coins });
        this.showCoins();
    },

    onWatchAd: function () {
        var self = this;
        if (!this.ready) { return; }
        Untils.rewardedBreak().then(function (rewarded) {
            if (rewarded) {
                self.coins += 50;
                UntilsPrefs.setInt("coins", self.coins);
                self.showCoins();
                self.setStatus("+50 coins!");
            } else {
                self.setStatus("Ads are not live yet, so no reward.");
            }
        });
    },

    onReset: function () {
        if (!this.ready) { return; }
        this.coins = 0;
        UntilsPrefs.deleteAll();
        this.showCoins();
        this.setStatus("Progress reset.");
    },

    onDestroy: function () { if (this.playing) { Untils.gameplayStop(); } },

    showCoins: function () { if (this.coinsLabel) { this.coinsLabel.string = "Coins: " + this.coins; } },
    setStatus: function (s) { if (this.statusLabel) { this.statusLabel.string = s; } }
});
