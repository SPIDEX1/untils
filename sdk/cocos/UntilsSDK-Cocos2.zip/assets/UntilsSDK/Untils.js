// Untils Cocos SDK v1.0.0 - for Cocos Creator 2.4.x, Web (HTML5) builds
// Docs: https://untils.pages.dev/developers/docs/
//
// Use:   const { Untils, UntilsPrefs } = require("Untils");
//        Untils.init().then(function () { ... });
//
// This file talks to untils.js (the HTML SDK). untils.js is copied into your build
// automatically from build-templates/web-mobile/untils.js.
// Note: inside your own scripts, always get Untils with require("Untils"), not from window.

(function () {
"use strict";
var SDK_NAME = "Cocos SDK";
var SDK_VERSION = "1.0.0";
var LS_KEY = "untils_cocos_prefs";
var W = (typeof window !== "undefined") ? window : undefined;

var debug = false;
var ready = false;
var env = "editor";               // "untils" (on the site), "offline" (your own PC / preview) or "editor"
var mobile = false;
var language = "en";
var player = { guest: true, name: "Guest" };
var html = null;                  // the HTML SDK (window.Untils)
var initP = null;
var loadingDone = false;
var pauseCbs = [];
var resumeCbs = [];

function log() { if (debug) { try { console.log.apply(console, ["[Untils]"].concat([].slice.call(arguments))); } catch (e) {} } }
function warn(m) { try { console.warn("[Untils] " + m); } catch (e) {} }
function fire(list) { list.forEach(function (f) { try { f(); } catch (e) { console.error(e); } }); }
function needInit(n) { if (!ready) { warn("Call Untils.init() first, before " + n + "()."); return false; } return true; }

function loadScript(src) {
    return new Promise(function (resolve) {
        try {
            var d = W.document, s = d.createElement("script"), done = false;
            var fin = function (ok) { if (!done) { done = true; resolve(ok); } };
            s.src = src; s.async = true;
            s.onload = function () { fin(true); };
            s.onerror = function () { fin(false); };
            d.head.appendChild(s);
            setTimeout(function () { fin(false); }, 6000);
        } catch (e) { resolve(false); }
    });
}

function lsGet() {
    try { if (W && W.localStorage) { return W.localStorage.getItem(LS_KEY); } } catch (e) {}
    try { return cc.sys.localStorage.getItem(LS_KEY); } catch (e) {}
    return null;
}
function lsSet(v) {
    try { if (W && W.localStorage) { W.localStorage.setItem(LS_KEY, v); return; } } catch (e) {}
    try { cc.sys.localStorage.setItem(LS_KEY, v); } catch (e) {}
}

function doPause() {
    if (Untils.autoPause) { try { cc.game.pause(); } catch (e) {} }
    fire(pauseCbs);
}
function doResume() {
    if (Untils.autoPause) { try { cc.game.resume(); } catch (e) {} }
    fire(resumeCbs);
}
function info() { return { name: SDK_NAME, version: SDK_VERSION, env: env, isMobile: mobile, player: player, language: language }; }

var Untils = {
    sdkName: SDK_NAME,
    version: SDK_VERSION,

    // When true (default) the game loop and sound are paused while the tab is hidden.
    autoPause: true,
    // When true (default) loadingStart / loadingFinished are sent for you. Set to false to call them yourself.
    autoLoading: true,
    // In preview / offline only: what a rewarded ad returns, so you can test your reward code.
    editorRewardedResult: true,

    get isReady() { return ready; },
    get env() { return env; },
    get isMobile() { return mobile; },
    get language() { return language; },
    get player() { return player; },
    get adsAvailable() { return false; },   // ads are not live yet

    // Starts the SDK and loads saved data. Call it first. Never rejects. Waits up to about 3 seconds for UNTILS.
    init: function (opts) {
        if (opts && opts.debug) { debug = true; }
        if (initP) { return initP; }
        mobile = !!cc.sys.isMobile;
        initP = new Promise(function (resolve) {
            var finish = function () {
                UntilsPrefs._load().then(function () {
                    ready = true;
                    log("ready", info());
                    if (Untils.autoLoading) { Untils._autoLoading(); }
                    resolve(info());
                });
            };
            if (!W || !W.document) { env = "editor"; finish(); return; }
            var go = function () {
                html = W.Untils || null;
                if (!html) {
                    warn("untils.js was not found. Copy untils.js to build-templates/web-mobile/ (it is in the SDK zip) and build again. Running offline.");
                    env = "offline"; finish(); return;
                }
                html.init({ debug: debug, via: "cocos" }).then(function (r) {
                    env = r.env || "offline";
                    mobile = !!r.isMobile; language = r.language || "en";
                    player = r.player || player;
                    html.onPause(doPause); html.onResume(doResume);
                    if (html.announce) { html.announce(SDK_NAME, SDK_VERSION); }
                    finish();
                }, function () { env = "offline"; finish(); });
            };
            if (W.Untils) { go(); } else { loadScript("untils.js").then(go); }
        });
        return initP;
    },

    setDebug: function (on) { debug = !!on; if (html && html.setDebug) { html.setDebug(!!on); } },

    // ---------- Loading and gameplay state ----------
    loadingStart: function () { if (needInit("loadingStart") && html) { html.loadingStart(); } },
    loadingFinished: function () { if (needInit("loadingFinished") && html) { html.loadingFinished(); } },
    gameplayStart: function () { if (needInit("gameplayStart") && html) { html.gameplayStart(); } },
    gameplayStop: function () { if (needInit("gameplayStop") && html) { html.gameplayStop(); } },

    // ---------- Pause / resume (tab hidden or shown) ----------
    onPause: function (cb) { if (typeof cb === "function") { pauseCbs.push(cb); } },
    onResume: function (cb) { if (typeof cb === "function") { resumeCbs.push(cb); } },
    offPause: function (cb) { var i = pauseCbs.indexOf(cb); if (i > -1) { pauseCbs.splice(i, 1); } },
    offResume: function (cb) { var i = resumeCbs.indexOf(cb); if (i > -1) { resumeCbs.splice(i, 1); } },

    // ---------- Player, language, share links ----------
    getPlayer: function () { return html ? html.getPlayer() : Promise.resolve(player); },
    getLanguage: function () { return language; },
    shareableURL: function (values) {
        if (html) { return html.shareableURL(values || {}); }
        return (W && W.location) ? (W.location.origin + W.location.pathname) : "";
    },
    getURLParam: function (name) { return html ? html.getURLParam(name) : undefined; },

    // ---------- Screen ----------
    requestFullscreen: function () { if (needInit("requestFullscreen") && html) { html.requestFullscreen(); } },
    exitFullscreen: function () { if (needInit("exitFullscreen") && html) { html.exitFullscreen(); } },

    // ---------- Your own events (stats come later) ----------
    track: function (name, data) { if (needInit("track") && html) { html.track(name, data); } },

    // ---------- Ads (not live yet) ----------
    // Interstitial resolves true (continue). Rewarded resolves false until ads are live.
    showAd: function (type) {
        if (type !== "interstitial" && type !== "rewarded") { warn('showAd("interstitial" | "rewarded")'); return Promise.resolve(false); }
        if (!html || env !== "untils") { return Promise.resolve(type === "rewarded" ? Untils.editorRewardedResult : true); }
        return html.showAd(type);
    },
    commercialBreak: function () { return Untils.showAd("interstitial").then(function () {}); },
    rewardedBreak: function () { return Untils.showAd("rewarded"); },

    // ---------- Leaderboards (coming soon, safe to call now) ----------
    submitScore: function (board, score) { return html ? html.submitScore(board, score) : Promise.resolve(false); },

    // ---------- Save data (same as UntilsPrefs, async style like the HTML SDK) ----------
    save: function (key, value) { return Promise.resolve(UntilsPrefs.setJSON(key, value)); },
    load: function (key, fallback) { return Promise.resolve(UntilsPrefs.getJSON(key, fallback)); },
    remove: function (key) { UntilsPrefs.deleteKey(key); return Promise.resolve(true); },
    clearSave: function () { UntilsPrefs.deleteAll(); return Promise.resolve(true); },
    keys: function () { return UntilsPrefs.keys(); },

    // internal: loading events done for you (start now, finished on the first drawn frame)
    _autoLoading: function () {
        if (!html) { return; }
        html.loadingStart();
        var fin = function () { if (!loadingDone) { loadingDone = true; html.loadingFinished(); } };
        try { cc.director.once(cc.Director.EVENT_AFTER_DRAW, fin); } catch (e) {}
        setTimeout(fin, 2500);
    }
};

// Save-safe replacement for cc.sys.localStorage. Saves itself shortly after each change (about 900 KB per game).
var prefsData = {};
var prefsTimer = 0;

function prefsSchedule() {
    if (prefsTimer) { clearTimeout(prefsTimer); }
    prefsTimer = setTimeout(UntilsPrefs.save, 150);
}
function prefsPut(key, value) {
    if (!needInit("UntilsPrefs.set")) { return false; }
    if (typeof key !== "string" || !key) { warn("Prefs key must be a non-empty string."); return false; }
    prefsData[key] = value;
    if (html) { html.save(key, value); } else { prefsSchedule(); }
    return true;
}
function prefsGet(key) {
    if (!needInit("UntilsPrefs.get")) { return undefined; }
    return Object.prototype.hasOwnProperty.call(prefsData, key) ? prefsData[key] : undefined;
}
function trunc(n) { return n < 0 ? Math.ceil(n) : Math.floor(n); }

var UntilsPrefs = {
    // internal: loads everything that was saved before
    _load: function () {
        prefsData = {};
        if (html) {
            var keys = [];
            try { keys = html.keys(); } catch (e) { keys = []; }
            return Promise.all(keys.map(function (k) { return html.load(k, null).then(function (v) { prefsData[k] = v; }); })).then(function () {});
        }
        try { var raw = lsGet(); prefsData = raw ? (JSON.parse(raw) || {}) : {}; } catch (e) { prefsData = {}; }
        return Promise.resolve();
    },

    setInt: function (key, value) { prefsPut(key, trunc(Number(value) || 0)); },
    getInt: function (key, def) { var v = prefsGet(key); return typeof v === "number" ? trunc(v) : (def === undefined ? 0 : def); },
    setFloat: function (key, value) { prefsPut(key, Number(value) || 0); },
    getFloat: function (key, def) { var v = prefsGet(key); return typeof v === "number" ? v : (def === undefined ? 0 : def); },
    setString: function (key, value) { prefsPut(key, String(value)); },
    getString: function (key, def) { var v = prefsGet(key); return typeof v === "string" ? v : (def === undefined ? "" : def); },
    setBool: function (key, value) { prefsPut(key, !!value); },
    getBool: function (key, def) { var v = prefsGet(key); return typeof v === "boolean" ? v : (def === undefined ? false : def); },
    // Any JSON value: object, array, number, text.
    setJSON: function (key, value) {
        try { return prefsPut(key, JSON.parse(JSON.stringify(value === undefined ? null : value))); } catch (e) { warn("setJSON(): value must be JSON-safe."); return false; }
    },
    getJSON: function (key, def) { var v = prefsGet(key); return (v === undefined || v === null) ? def : v; },

    hasKey: function (key) { return Object.prototype.hasOwnProperty.call(prefsData, key); },
    keys: function () { return Object.keys(prefsData); },
    deleteKey: function (key) {
        if (!needInit("UntilsPrefs.deleteKey")) { return; }
        delete prefsData[key];
        if (html) { html.remove(key); } else { prefsSchedule(); }
    },
    deleteAll: function () {
        if (!needInit("UntilsPrefs.deleteAll")) { return; }
        prefsData = {};
        if (html) { html.clearSave(); } else { prefsSchedule(); }
    },
    // Saves now (it already saves by itself shortly after each change).
    save: function () {
        if (prefsTimer) { clearTimeout(prefsTimer); prefsTimer = 0; }
        if (!html) { try { lsSet(JSON.stringify(prefsData)); } catch (e) {} }
    }
};

module.exports = { Untils: Untils, UntilsPrefs: UntilsPrefs };
})();
