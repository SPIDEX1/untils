Unity SDK (WebGL) 1.1.0  -  for Unity 6 (6000.x)
======================================================================
(Made for Unity 6 (6000.x). Other Unity versions have their own package on the docs page.)

1. Unzip this file INTO your Unity project folder (the folder that contains "Assets").
   Say yes to merging the "Assets" folder.
2. In Unity: menu  Untils > Apply recommended WebGL settings.
   (Or set by hand: Player Settings > Resolution and Presentation > WebGL Template = "Untils";
    Publishing Settings > Compression Format = Gzip, Decompression Fallback = on, Data Caching = off.)
3. In your code call Untils.Init once at the start, and use UntilsPrefs instead of PlayerPrefs.
   See Assets/UntilsSDK/Samples/UntilsExample.cs for a full example.
4. File > Build Settings > WebGL > Build.
5. Zip the CONTENTS of the build folder (index.html must be at the top of the zip) and upload it
   in your UNTILS developer dashboard. After upload, open the Inspector view to check the SDK.

Docs: https://untils.pages.dev/developers/docs/
