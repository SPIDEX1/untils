// Untils SDK for Unity (WebGL) v1.1.0 - for Unity 2020.1 up to Unity 6
// Docs: https://untils.pages.dev/developers/docs/
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif

public enum UntilsAdType { Interstitial, Rewarded }

[Serializable]
public class UntilsPlayer
{
    public bool guest = true;
    public string name = "Guest";
}

[Serializable]
internal class UntilsValue { public string value; }

public static class Untils
{
    public const string SdkName = "Untils SDK Unity";
    public const string Version = "1.1.0";

#if UNITY_WEBGL && !UNITY_EDITOR
    internal static readonly bool Web = true;
    [DllImport("__Internal")] private static extern void UntilsBridge_Call(int id, string name, string arg);
    [DllImport("__Internal")] private static extern void UntilsBridge_Do(string name, string arg);
    [DllImport("__Internal")] private static extern string UntilsBridge_Get(string name, string arg);
#else
    internal static readonly bool Web = false;
#endif

    // ---------- State ----------
    public static bool IsReady { get; private set; }
    public static string Env { get; private set; } = "editor";      // "untils", "offline" or "editor"
    public static bool IsMobile { get; private set; }
    public static string Language { get; private set; } = "en";
    public static UntilsPlayer Player { get; private set; } = new UntilsPlayer();
    public static bool AdsAvailable { get { return false; } }       // ads are not live yet

    /// <summary>When true, the game is paused (Time.timeScale = 0, audio paused) while the tab is hidden.</summary>
    public static bool AutoPause = true;
    /// <summary>In the Unity Editor only: what a rewarded ad returns, so you can test your reward code.</summary>
    public static bool EditorRewardedResult = true;

    public static event Action OnPause;
    public static event Action OnResume;

    [Serializable]
    internal class InitReply
    {
        public string error;
        public string env;
        public bool isMobile;
        public string language;
        public UntilsPlayer player;
    }

    [Serializable]
    internal class OkReply { public bool ok; }

    // ---------- Bridge plumbing ----------
    private static GameObject runnerGo;
    private static int nextId;
    private static readonly Dictionary<int, Action<string>> waiting = new Dictionary<int, Action<string>>();

    internal static void EnsureRunner()
    {
        if (runnerGo != null) return;
        runnerGo = new GameObject("UntilsSDKRunner");
        UnityEngine.Object.DontDestroyOnLoad(runnerGo);
        runnerGo.AddComponent<UntilsSDKRunner>();
    }

    internal static void Call(string name, string arg, Action<string> callback)
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        EnsureRunner();
        int id = ++nextId;
        if (callback != null) waiting[id] = callback;
        UntilsBridge_Call(id, name, arg ?? "");
#endif
    }

    internal static void Do(string name, string arg = "")
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        UntilsBridge_Do(name, arg ?? "");
#endif
    }

    internal static string Get(string name, string arg = "")
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        return UntilsBridge_Get(name, arg ?? "");
#else
        return "";
#endif
    }

    internal static void HandleResult(string msg)
    {
        if (string.IsNullOrEmpty(msg)) return;
        int bar = msg.IndexOf('|');
        if (bar < 1) return;
        int id;
        if (!int.TryParse(msg.Substring(0, bar), out id)) return;
        string json = msg.Substring(bar + 1);
        Action<string> cb;
        if (waiting.TryGetValue(id, out cb))
        {
            waiting.Remove(id);
            cb(json);
        }
    }

    internal static T Parse<T>(string json) where T : class
    {
        try { return JsonUtility.FromJson<T>(json); }
        catch (Exception) { return null; }
    }

    internal static string Esc(string s)
    {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.Length + 8);
        foreach (char c in s)
        {
            switch (c)
            {
                case '\\': sb.Append("\\\\"); break;
                case '"': sb.Append("\\\""); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                    break;
            }
        }
        return sb.ToString();
    }

    internal static void SaveValue(string key, string value)
    {
        Do("save", "{\"key\":\"" + Esc(key) + "\",\"value\":\"" + Esc(value) + "\"}");
    }

    // ---------- Pause / resume ----------
    private static bool paused;
    private static float prevScale = 1f;
    private static bool prevAudioPause;

    internal static void HandlePause()
    {
        if (paused) return;
        paused = true;
        if (AutoPause)
        {
            prevScale = Time.timeScale;
            prevAudioPause = AudioListener.pause;
            Time.timeScale = 0f;
            AudioListener.pause = true;
        }
        UntilsPrefs.Flush();
        Action h = OnPause;
        if (h != null) h();
    }

    internal static void HandleResume()
    {
        if (!paused) return;
        paused = false;
        if (AutoPause)
        {
            Time.timeScale = prevScale;
            AudioListener.pause = prevAudioPause;
        }
        Action h = OnResume;
        if (h != null) h();
    }

    // ---------- Start ----------
    /// <summary>Call this first (for example in Start). onReady(true) runs when saved data is loaded.</summary>
    public static void Init(Action<bool> onReady = null)
    {
        if (IsReady)
        {
            if (onReady != null) onReady(true);
            return;
        }
        EnsureRunner();
        if (!Web)
        {
            Env = "editor";
            IsMobile = Application.isMobilePlatform;
            IsReady = true;
            UntilsPrefs.Load(delegate { if (onReady != null) onReady(true); });
            return;
        }
        Call("init", "", delegate (string json)
        {
            InitReply r = Parse<InitReply>(json);
            if (r != null && string.IsNullOrEmpty(r.error))
            {
                Env = string.IsNullOrEmpty(r.env) ? "untils" : r.env;
                IsMobile = r.isMobile;
                if (!string.IsNullOrEmpty(r.language)) Language = r.language;
                if (r.player != null) Player = r.player;
            }
            else
            {
                Env = "offline";
            }
            IsReady = true;
            UntilsPrefs.Load(delegate { if (onReady != null) onReady(true); });
        });
    }

    public static void SetDebug(bool on) { Do("setDebug", on ? "{\"on\":true}" : "{\"on\":false}"); }

    // ---------- Loading and gameplay ----------
    public static void LoadingStart() { Do("loadingStart"); }
    public static void LoadingFinished() { Do("loadingFinished"); }
    public static void GameplayStart() { Do("gameplayStart"); }
    public static void GameplayStop() { Do("gameplayStop"); }

    // ---------- Player, share links, screen, stats ----------
    public static void GetPlayer(Action<UntilsPlayer> done)
    {
        if (done == null) return;
        if (!Web) { done(Player); return; }
        Call("getPlayer", "", delegate (string json)
        {
            UntilsPlayer p = Parse<UntilsPlayer>(json);
            done(p ?? Player);
        });
    }

    public static string ShareableURL(Dictionary<string, string> values)
    {
        if (!Web) return "";
        StringBuilder sb = new StringBuilder("{\"params\":{");
        bool first = true;
        if (values != null)
        {
            foreach (KeyValuePair<string, string> kv in values)
            {
                if (!first) sb.Append(',');
                first = false;
                sb.Append('"').Append(Esc(kv.Key)).Append("\":\"").Append(Esc(kv.Value)).Append('"');
            }
        }
        sb.Append("}}");
        return Get("shareableURL", sb.ToString());
    }

    public static string GetURLParam(string name)
    {
        if (!Web || string.IsNullOrEmpty(name)) return null;
        string v = Get("getURLParam", "{\"name\":\"" + Esc(name) + "\"}");
        return string.IsNullOrEmpty(v) ? null : v;
    }

    public static void RequestFullscreen() { Do("requestFullscreen"); }
    public static void ExitFullscreen() { Do("exitFullscreen"); }

    /// <summary>Send your own event, for example Track("level_complete", "{\"level\":3}"). dataJson is optional.</summary>
    public static void Track(string name, string dataJson = null)
    {
        if (string.IsNullOrEmpty(name)) return;
        Do("track", "{\"name\":\"" + Esc(name) + "\",\"dataJson\":\"" + Esc(dataJson) + "\"}");
    }

    // ---------- Ads (not live yet) ----------
    /// <summary>Interstitial: done(true) when it is fine to continue. Rewarded: done(true) only if the player earned the reward.</summary>
    public static void ShowAd(UntilsAdType type, Action<bool> done)
    {
        if (!Web)
        {
            if (done != null) done(type == UntilsAdType.Interstitial ? true : EditorRewardedResult);
            return;
        }
        string t = type == UntilsAdType.Interstitial ? "interstitial" : "rewarded";
        Call("showAd", "{\"type\":\"" + t + "\"}", delegate (string json)
        {
            OkReply r = Parse<OkReply>(json);
            bool ok = r != null && r.ok;
            if (done != null) done(type == UntilsAdType.Interstitial ? true : ok);
        });
    }

    public static void CommercialBreak(Action done)
    {
        ShowAd(UntilsAdType.Interstitial, delegate (bool ok) { if (done != null) done(); });
    }

    public static void RewardedBreak(Action<bool> done)
    {
        ShowAd(UntilsAdType.Rewarded, done);
    }

    // ---------- Leaderboards (coming with player login) ----------
    public static void SubmitScore(string board, double score, Action<bool> done = null)
    {
        if (!Web) { if (done != null) done(false); return; }
        string arg = "{\"board\":\"" + Esc(board) + "\",\"score\":" + score.ToString("R", CultureInfo.InvariantCulture) + "}";
        Call("submitScore", arg, delegate (string json)
        {
            OkReply r = Parse<OkReply>(json);
            if (done != null) done(r != null && r.ok);
        });
    }
}
