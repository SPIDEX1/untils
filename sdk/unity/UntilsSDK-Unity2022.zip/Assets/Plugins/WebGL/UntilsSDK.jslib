// Untils SDK for Unity (WebGL) - bridge between C# and untils.js (Untils SDK HTML).
// Needs: the "Untils" WebGL template (loads untils.js and sets window.unityInstance).
mergeInto(LibraryManager.library, {

  UntilsBridge_Call: function (id, namePtr, argPtr) {
    var name = UTF8ToString(namePtr), arg = UTF8ToString(argPtr), a = {};
    var send = function (method) {
      try { window.unityInstance.SendMessage("UntilsSDKRunner", method, ""); } catch (e) {}
    };
    var reply = function (res) {
      try {
        window.unityInstance.SendMessage("UntilsSDKRunner", "OnBridgeResult", id + "|" + JSON.stringify(res === undefined ? null : res));
      } catch (e) { console.warn("[Untils] could not reply to Unity", e); }
    };
    var U = window.Untils;
    if (!U) { reply({ error: "untils.js is not loaded. Use the Untils WebGL template." }); return; }
    try { a = arg ? JSON.parse(arg) : {}; } catch (e) { a = {}; }
    try {
      if (name === "init") {
        U.init().then(function (info) {
          if (!window.__untilsUnityHooked) {
            window.__untilsUnityHooked = true;
            U.onPause(function () { send("OnPause"); });
            U.onResume(function () { send("OnResume"); });
          }
          reply(info);
        }, function () { reply({ error: "init failed" }); });
      } else if (name === "load") {
        U.load(a.key, null).then(function (v) { reply({ value: v }); });
      } else if (name === "showAd") {
        U.showAd(a.type).then(function (ok) { reply({ ok: !!ok }); });
      } else if (name === "getPlayer") {
        U.getPlayer().then(function (p) { reply(p); });
      } else if (name === "submitScore") {
        U.submitScore(a.board, a.score).then(function (ok) { reply({ ok: !!ok }); });
      } else {
        reply({ error: "unknown call " + name });
      }
    } catch (e) { reply({ error: String(e) }); }
  },

  UntilsBridge_Do: function (namePtr, argPtr) {
    var name = UTF8ToString(namePtr), arg = UTF8ToString(argPtr), a = {}, U = window.Untils;
    if (!U) return;
    try { a = arg ? JSON.parse(arg) : {}; } catch (e) { a = {}; }
    try {
      switch (name) {
        case "loadingStart": U.loadingStart(); break;
        case "loadingFinished": U.loadingFinished(); break;
        case "gameplayStart": U.gameplayStart(); break;
        case "gameplayStop": U.gameplayStop(); break;
        case "save": U.save(a.key, a.value); break;
        case "remove": U.remove(a.key); break;
        case "clearSave": U.clearSave(); break;
        case "requestFullscreen": U.requestFullscreen(); break;
        case "exitFullscreen": U.exitFullscreen(); break;
        case "setDebug": U.setDebug(!!a.on); break;
        case "track":
          var d = null;
          try { d = a.dataJson ? JSON.parse(a.dataJson) : null; } catch (e2) { d = null; }
          U.track(a.name, d);
          break;
      }
    } catch (e) { console.warn("[Untils]", e); }
  },

  UntilsBridge_Get: function (namePtr, argPtr) {
    var name = UTF8ToString(namePtr), arg = UTF8ToString(argPtr), a = {}, U = window.Untils, r = "";
    try { a = arg ? JSON.parse(arg) : {}; } catch (e) { a = {}; }
    try {
      if (U) {
        if (name === "env") r = U.env;
        else if (name === "isMobile") r = U.isMobile ? "1" : "0";
        else if (name === "language") r = U.getLanguage();
        else if (name === "shareableURL") r = U.shareableURL(a.params || {});
        else if (name === "getURLParam") { var v = U.getURLParam(a.name); r = v === undefined ? "" : v; }
      }
    } catch (e) { r = ""; }
    r = String(r === undefined || r === null ? "" : r);
    var size = lengthBytesUTF8(r) + 1, buf = _malloc(size);
    stringToUTF8(r, buf, size);
    return buf;
  }
});
