#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class UntilsSetup
{
    [MenuItem("Untils/Apply recommended WebGL settings")]
    public static void Apply()
    {
        PlayerSettings.WebGL.template = "PROJECT:Untils";
        PlayerSettings.WebGL.dataCaching = false;
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Gzip;
        PlayerSettings.WebGL.decompressionFallback = true;
        EditorUtility.DisplayDialog("Untils SDK",
            "Done:\n\n- WebGL Template: Untils\n- Data Caching: off\n- Compression: Gzip\n- Decompression Fallback: on\n\n" +
            "Next: File > Build Settings > WebGL > Build. Zip the CONTENTS of the build folder (index.html must be at the top of the zip).",
            "OK");
    }

    [MenuItem("Untils/Open documentation")]
    public static void OpenDocs()
    {
        Application.OpenURL("https://untils.pages.dev/developers/docs/");
    }
}
#endif
