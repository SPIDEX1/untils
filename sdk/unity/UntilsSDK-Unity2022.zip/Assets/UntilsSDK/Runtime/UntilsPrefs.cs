// UntilsPrefs: use it exactly like PlayerPrefs. In the UNTILS sandbox PlayerPrefs is not saved,
// UntilsPrefs is. In the Unity Editor and other platforms it simply uses PlayerPrefs.
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public static class UntilsPrefs
{
    [Serializable]
    internal class Entry { public string k; public string t; public string v; }

    [Serializable]
    internal class Store { public List<Entry> items = new List<Entry>(); }

    private const string SdkKey = "unity_prefs";
    private static readonly Dictionary<string, Entry> map = new Dictionary<string, Entry>();
    private static bool dirty;
    private static float changedAt;

    // ----- same names as PlayerPrefs -----
    public static void SetInt(string key, int value)
    {
        if (!Untils.Web) { PlayerPrefs.SetInt(key, value); return; }
        Put(key, "i", value.ToString(CultureInfo.InvariantCulture));
    }

    public static int GetInt(string key, int defaultValue = 0)
    {
        if (!Untils.Web) return PlayerPrefs.GetInt(key, defaultValue);
        string s; int r;
        if (Read(key, "i", out s) && int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out r)) return r;
        return defaultValue;
    }

    public static void SetFloat(string key, float value)
    {
        if (!Untils.Web) { PlayerPrefs.SetFloat(key, value); return; }
        Put(key, "f", value.ToString("R", CultureInfo.InvariantCulture));
    }

    public static float GetFloat(string key, float defaultValue = 0f)
    {
        if (!Untils.Web) return PlayerPrefs.GetFloat(key, defaultValue);
        string s; float r;
        if (Read(key, "f", out s) && float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out r)) return r;
        return defaultValue;
    }

    public static void SetString(string key, string value)
    {
        if (!Untils.Web) { PlayerPrefs.SetString(key, value); return; }
        Put(key, "s", value ?? "");
    }

    public static string GetString(string key, string defaultValue = "")
    {
        if (!Untils.Web) return PlayerPrefs.GetString(key, defaultValue);
        string s;
        return Read(key, "s", out s) ? s : defaultValue;
    }

    public static bool HasKey(string key)
    {
        if (!Untils.Web) return PlayerPrefs.HasKey(key);
        return key != null && map.ContainsKey(key);
    }

    public static void DeleteKey(string key)
    {
        if (!Untils.Web) { PlayerPrefs.DeleteKey(key); return; }
        if (key != null && map.Remove(key)) Touch();
    }

    public static void DeleteAll()
    {
        if (!Untils.Web) { PlayerPrefs.DeleteAll(); return; }
        map.Clear();
        Touch();
    }

    /// <summary>Saves right now. It also saves by itself shortly after every change.</summary>
    public static void Save() { Flush(); }

    // ----- internal -----
    private static void Touch() { dirty = true; changedAt = Time.unscaledTime; }

    private static void Put(string key, string type, string value)
    {
        if (string.IsNullOrEmpty(key)) return;
        Entry e;
        if (!map.TryGetValue(key, out e))
        {
            e = new Entry();
            e.k = key;
            map[key] = e;
        }
        e.t = type;
        e.v = value;
        Touch();
    }

    private static bool Read(string key, string type, out string value)
    {
        Entry e;
        if (key != null && map.TryGetValue(key, out e) && e.t == type)
        {
            value = e.v;
            return true;
        }
        value = null;
        return false;
    }

    internal static void Load(Action done)
    {
        if (!Untils.Web)
        {
            if (done != null) done();
            return;
        }
        Untils.Call("load", "{\"key\":\"" + SdkKey + "\"}", delegate (string json)
        {
            UntilsValue r = Untils.Parse<UntilsValue>(json);
            map.Clear();
            if (r != null && !string.IsNullOrEmpty(r.value))
            {
                Store s = Untils.Parse<Store>(r.value);
                if (s != null && s.items != null)
                {
                    foreach (Entry e in s.items)
                    {
                        if (e != null && !string.IsNullOrEmpty(e.k)) map[e.k] = e;
                    }
                }
            }
            if (done != null) done();
        });
    }

    internal static void Flush()
    {
        if (!Untils.Web) { PlayerPrefs.Save(); return; }
        if (!dirty) return;
        dirty = false;
        Store s = new Store();
        foreach (KeyValuePair<string, Entry> kv in map) s.items.Add(kv.Value);
        Untils.SaveValue(SdkKey, JsonUtility.ToJson(s));
    }

    internal static void Tick()
    {
        if (dirty && Time.unscaledTime - changedAt > 0.3f) Flush();
    }
}
