// Created automatically by Untils.Init(). Do not add this yourself.
using UnityEngine;

public class UntilsSDKRunner : MonoBehaviour
{
    private void Update() { UntilsPrefs.Tick(); }
    private void OnApplicationPause(bool paused) { if (paused) UntilsPrefs.Flush(); }
    private void OnApplicationQuit() { UntilsPrefs.Flush(); }

    // Called from the browser through SendMessage (see UntilsSDK.jslib). Names must not change.
    public void OnBridgeResult(string msg) { Untils.HandleResult(msg); }
    public void OnPause() { Untils.HandlePause(); }
    public void OnResume() { Untils.HandleResume(); }
}
