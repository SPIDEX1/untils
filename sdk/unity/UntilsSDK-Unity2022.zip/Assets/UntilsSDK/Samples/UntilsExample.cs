// Example: add this script to an empty GameObject in a new scene, build for WebGL with the Untils template.
using UnityEngine;

public class UntilsExample : MonoBehaviour
{
    private int coins;
    private bool ready;
    private bool playing;
    private string msg = "starting...";

    private void Start()
    {
        Untils.OnPause += delegate { msg = "Paused"; };
        Untils.OnResume += delegate { msg = "Welcome back!"; };

        Untils.Init(delegate (bool ok)
        {
            coins = UntilsPrefs.GetInt("coins", 0);          // saved progress
            ready = true;
            msg = "SDK " + Untils.Version + " | env: " + Untils.Env + " | " + (Untils.IsMobile ? "mobile" : "desktop") + " | " + Untils.Language;
        });
    }

    private void OnGUI()
    {
        int fs = Mathf.Max(18, Screen.height / 20);
        GUIStyle label = new GUIStyle(GUI.skin.label);
        label.fontSize = fs;
        label.alignment = TextAnchor.MiddleCenter;
        GUIStyle button = new GUIStyle(GUI.skin.button);
        button.fontSize = fs;

        GUILayout.BeginArea(new Rect(20, 20, Screen.width - 40, Screen.height - 40));
        GUILayout.Label("Coin Tapper (Unity)", label);
        GUILayout.Label(msg, label);
        GUILayout.Label("Coins: " + coins, label);

        if (ready && GUILayout.Button("TAP!", button, GUILayout.Height(fs * 3)))
        {
            if (!playing) { playing = true; Untils.GameplayStart(); }
            coins++;
            UntilsPrefs.SetInt("coins", coins);               // saved automatically
        }
        if (ready && GUILayout.Button("Watch ad: +50 coins", button, GUILayout.Height(fs * 2)))
        {
            Untils.RewardedBreak(delegate (bool rewarded)
            {
                if (rewarded) { coins += 50; UntilsPrefs.SetInt("coins", coins); msg = "+50 coins!"; }
                else msg = "Ads are not live yet, so no reward.";
            });
        }
        if (ready && GUILayout.Button("Reset", button))
        {
            coins = 0;
            UntilsPrefs.DeleteAll();
            msg = "Progress reset.";
        }
        GUILayout.EndArea();
    }
}
